var searchData=
[
  ['gpupreference_2ehpp_0',['GpuPreference.hpp',['../GpuPreference_8hpp.html',1,'']]]
];
